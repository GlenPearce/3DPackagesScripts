import bpy, os


def image_folder(file_name=""):
    return os.path.dirname(__file__)
