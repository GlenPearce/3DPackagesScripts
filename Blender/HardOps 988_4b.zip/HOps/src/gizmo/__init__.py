import bpy
from bpy.utils import register_class, unregister_class

Classes = (
    )


# def register():

    # for cls in classes:
    #     register_class(cls)
    #register_class(array.HOPS_OT_ArrayGizmoGroup)


# def unregister():

    # for cls in classes:
    #     unregister_class(cls)
    # unregister_class(array.HOPS_OT_ArrayGizmoGroup)
